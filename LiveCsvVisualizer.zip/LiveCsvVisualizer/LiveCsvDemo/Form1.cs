using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace LiveCsvDemo
{
    public partial class Form1 : Form
    {
        private List<int> values = new();
        private List<int> displayedValues = new();
        private int currentIndex = 0;

        private Label titleLabel = new();
        private Label subtitleLabel = new();
        private Label valueLabel = new();
        private Label countLabel = new();
        private Label statusLabel = new();
        private Panel chartPanel = new();
        private Button startButton = new();
        private Button resetButton = new();

        private System.Windows.Forms.Timer timer = new();

        public Form1()
        {
            InitializeComponent();

            Text = "Live CSV Data Visualizer";
            Size = new Size(1000, 700);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(245, 247, 250);

            CreateUI();
            LoadCsv();
        }

        private void CreateUI()
        {
            titleLabel.Text = "Live CSV Data Visualizer";
            titleLabel.Font = new Font("Segoe UI", 23, FontStyle.Bold);
            titleLabel.ForeColor = Color.FromArgb(30, 41, 59);
            titleLabel.Location = new Point(35, 25);
            titleLabel.AutoSize = true;
            Controls.Add(titleLabel);

            subtitleLabel.Text = "Real-time monitoring of CSV values";
            subtitleLabel.Font = new Font("Segoe UI", 10);
            subtitleLabel.ForeColor = Color.Gray;
            subtitleLabel.Location = new Point(38, 72);
            subtitleLabel.AutoSize = true;
            Controls.Add(subtitleLabel);

            valueLabel.Text = "Current Value: --";
            valueLabel.Font = new Font("Segoe UI", 19, FontStyle.Bold);
            valueLabel.ForeColor = Color.RoyalBlue;
            valueLabel.Location = new Point(40, 125);
            valueLabel.AutoSize = true;
            Controls.Add(valueLabel);

            countLabel.Text = "Processed: 0 / 0";
            countLabel.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            countLabel.Location = new Point(40, 175);
            countLabel.AutoSize = true;
            Controls.Add(countLabel);

            statusLabel.Text = "Status: Ready";
            statusLabel.Font = new Font("Segoe UI", 10);
            statusLabel.ForeColor = Color.DarkGreen;
            statusLabel.Location = new Point(40, 210);
            statusLabel.AutoSize = true;
            Controls.Add(statusLabel);

            startButton.Text = "Start Processing";
            startButton.Location = new Point(40, 250);
            startButton.Size = new Size(160, 42);
            startButton.BackColor = Color.RoyalBlue;
            startButton.ForeColor = Color.White;
            startButton.FlatStyle = FlatStyle.Flat;
            startButton.Click += StartButton_Click;
            Controls.Add(startButton);

            resetButton.Text = "Reset";
            resetButton.Location = new Point(215, 250);
            resetButton.Size = new Size(110, 42);
            resetButton.Click += ResetButton_Click;
            Controls.Add(resetButton);

            chartPanel.Location = new Point(40, 325);
            chartPanel.Size = new Size(900, 290);
            chartPanel.BackColor = Color.White;
            chartPanel.Paint += ChartPanel_Paint;
            Controls.Add(chartPanel);


            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
        }

        private void LoadCsv()
        {
            string csvPath = Path.GetFullPath(
                Path.Combine(
                    AppContext.BaseDirectory,
                    "..", "..", "..", "..",
                    "Resources", "Raw", "sample_data.csv"
                )
            );

            if (!File.Exists(csvPath))
            {
                statusLabel.Text = "CSV file not found!";
                startButton.Enabled = false;
                return;
            }

            values = File.ReadAllLines(csvPath)
                .Skip(1)
                .Where(line => int.TryParse(line.Trim(), out _))
                .Select(line => int.Parse(line.Trim()))
                .Where(value => value >= 3 && value <= 17)
                .ToList();

            countLabel.Text = $"Processed: 0 / {values.Count}";
            statusLabel.Text = $"Status: Loaded {values.Count} CSV values";
        }

        private void StartButton_Click(object? sender, EventArgs e)
        {
            if (values.Count == 0)
            {
                MessageBox.Show("No valid CSV values found.");
                return;
            }

            if (currentIndex >= values.Count)
                ResetProcessing();

            startButton.Enabled = false;
            statusLabel.Text = "Status: Processing...";
            timer.Start();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (currentIndex >= values.Count)
            {
                timer.Stop();
                statusLabel.Text = "Status: Completed successfully!";
                startButton.Enabled = true;
                return;
            }

            int currentValue = values[currentIndex];
            displayedValues.Add(currentValue);

            valueLabel.Text = $"Current Value: {currentValue}";
            countLabel.Text =
                $"Processed: {currentIndex + 1} / {values.Count}";

            currentIndex++;
            chartPanel.Invalidate();

            if (currentIndex == values.Count)
            {
                timer.Stop();
                statusLabel.Text = "Status: Completed successfully!";
                startButton.Enabled = true;
            }
        }

        private void ResetButton_Click(object? sender, EventArgs e)
        {
            timer.Stop();
            ResetProcessing();
        }

        private void ResetProcessing()
        {
            currentIndex = 0;
            displayedValues.Clear();

            valueLabel.Text = "Current Value: --";
            countLabel.Text = $"Processed: 0 / {values.Count}";
            statusLabel.Text = "Status: Ready";
            startButton.Enabled = values.Count > 0;

            chartPanel.Invalidate();
        }

        private void ChartPanel_Paint(object? sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            graphics.Clear(Color.White);

            using Pen axisPen = new Pen(Color.LightGray, 1);
            using Pen linePen = new Pen(Color.RoyalBlue, 3);
            using Font chartFont = new Font("Segoe UI", 9);

            int left = 55;
            int top = 25;
            int width = chartPanel.Width - 85;
            int height = chartPanel.Height - 75;

            graphics.DrawLine(axisPen, left, top, left, top + height);
            graphics.DrawLine(axisPen, left, top + height,
                left + width, top + height);

            graphics.DrawString("17", chartFont, Brushes.Gray, 15, top - 5);
            graphics.DrawString("10", chartFont, Brushes.Gray,
                15, top + height / 2 - 7);
            graphics.DrawString("3", chartFont, Brushes.Gray,
                20, top + height - 10);

            graphics.DrawString("Processed Values",
                chartFont, Brushes.Gray, left + width / 2 - 50,
                top + height + 25);

            if (displayedValues.Count == 0)
            {
                graphics.DrawString("Click Start Processing to view live data",
                    new Font("Segoe UI", 12),
                    Brushes.Gray, left + 160, top + 90);
                return;
            }

            PointF[] points = displayedValues
                .Select((value, index) => new PointF(
                    left + index * width /
                    Math.Max(1, values.Count - 1),
                    top + (17 - value) * height / 14f
                ))
                .ToArray();

            if (points.Length > 1)
                graphics.DrawLines(linePen, points);

            foreach (PointF point in points)
            {
                graphics.FillEllipse(Brushes.OrangeRed,
                    point.X - 4, point.Y - 4, 8, 8);
            }
        }
    }
}
