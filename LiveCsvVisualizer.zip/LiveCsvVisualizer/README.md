# Live CSV Data Visualizer
##  Project Overview
The Live CSV Data Visualizer is a C# desktop application that reads integer values from a CSV file and displays them in real time using a live-updating line chart.
The application processes one value every second, updates the current value and progress counter, and visually represents the incoming data through a line chart.
## Project Objectives
•	Read integer values from a CSV file.
•	Process values within the range of 3 to 17.
•	Display one value every second.
•	Update the current value dynamically.
•	Visualize processed values using a live line chart.
•	Track processing progress.
•	Provide Start and Reset functionality.
## Technologies Used
Technology	Purpose
C#	Main programming language
.NET 10	Application development platform
Windows Forms	Desktop application UI
CSV	Input data source
System.IO	Reading CSV files
System.Windows.Forms.Timer	Processing values at one-second intervals
System.Drawing	Drawing the live chart
Visual Studio Code	Development environment
GitHub Copilot / ChatGPT	AI-assisted development and debugging
## Project Structure
LiveCsvVisualizer/
│
├── Resources/
│   └── Raw/
│       └── sample_data.csv
│
├── CsvGenerator/
│   ├── CsvGenerator.csproj
│   └── Program.cs
│
├── LiveCsvDemo/
│   ├── LiveCsvDemo.csproj
│   ├── Program.cs
│   ├── Form1.cs
│   └── Form1.Designer.cs
│
└── README.md
## Input Data
The application reads integer values from sample_data.csv.
Example:
Value
5
12
8
17
10
3
15
The sample CSV generator creates 50 random integer values between 3 and 17.
.   Application Workflow
.	The application loads the CSV file.
.	It reads and validates integer values.
.	The user clicks the Start Processing button.
.	A timer processes one value every second.
.	The current value is displayed on the screen.
.	The progress counter updates after every processed value.
.	The live line chart updates dynamically.
.	Processing stops after all available values have been processed.
.	The Reset button clears the chart and resets the processing count.
## Key Features
CSV Data Reading
Reads integer values from the CSV file and filters valid values between 3 and 17.
One-Second Processing
Uses a Windows Forms Timer with a 1000-millisecond interval to process one value at a time.
Live Line Chart
Uses Windows Forms drawing capabilities to plot processed values dynamically.
Progress Tracking
Displays the number of processed values against the total number of values.
Reset Functionality
Allows the user to clear the chart and restart processing from the beginning.
## How to Run the Application
Prerequisites
•	.NET 10 SDK
•	Visual Studio Code
•	C# Dev Kit extension Steps
1.	Open the LiveCsvVisualizer project folder in VS Code.
2.	Open the terminal.
3.	Navigate to the application folder:
cd LiveCsvDemo
4.	Run the application:
dotnet run
5.	Click Start Processing to begin.
6.	Click Reset to restart the demonstration.
9. Testing
The following functionalities were tested in the desktop prototype:
•	CSV file loading.
•	Integer value validation.
•	One-second processing interval.
•	Current value updates.
•	Progress counter updates.
•	Live chart updates.
•	Completion after processing all values.
•	Reset and restart functionality.
##  Current Implementation Status
The C# Windows Forms prototype is implemented and working.
The requested .NET MAUI Android implementation and Android device/emulator testing are pending the required IT-approved development workload and Android tooling.
##  Future Scope
•	Implement the application using .NET MAUI.
•	Deploy and test on an Android emulator or physical Android device.
•	Improve chart visualization and mobile responsiveness.
## Conclusion
This project demonstrates CSV-based data processing, timer-driven execution, real-time value updates, and dynamic line chart visualization using C# and .NET.
It provides a foundation for extending the prototype into a cross-platform .NET MAUI application.