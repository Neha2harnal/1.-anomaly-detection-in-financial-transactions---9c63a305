﻿using System;
using System.IO;

string csvPath = Path.Combine(
    "..",
    "Resources",
    "Raw",
    "sample_data.csv"
);

Random random = new Random();

using (StreamWriter writer = new StreamWriter(csvPath))
{
    writer.WriteLine("Value");

    for (int i = 0; i < 50; i++)
    {
        int value = random.Next(3, 18);
        writer.WriteLine(value);
    }
}

Console.WriteLine("50 random values generated successfully!");

